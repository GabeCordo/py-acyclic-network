class Supervisor:
    def __init__(self) -> None:
        pass

    def start_link(self):
        pass