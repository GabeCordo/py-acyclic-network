from src.core.types.request import Request

Queue = list[Request]
LinkerPath = str

