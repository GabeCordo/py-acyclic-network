
def test_lookup_index():
	assert True
